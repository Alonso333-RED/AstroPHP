# AstroPHP
This repository contains a web tool built in PHP for managing an astronomical database. It follows the MVC architecture and implements CRUD operations. The project is currently under development as part of a high school assignment.

This project is used with xampp.
