<?php
class Astro {
    public int $id;
    public string $name;
    public string $description;
    public string $type;
    public float $diameter;
    public float $mass;
    public int $discovery_year;
    public string $discovered_by;
    public float $temperature;
    public string $image;
}